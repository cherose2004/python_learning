# -*- coding: utf-8 -*-
# __author__ = "maple"
a = 123
print(a)
