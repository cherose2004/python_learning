import os
import time

from bson import ObjectId
from flask import Blueprint, jsonify, send_file, request

from BaiduAi import text2audio
from Config import RET, MongoDB, COVER_PATH, MUSIC_PATH
from redis_msg import get_msg_one

friends = Blueprint("friends", __name__)

@friends.route("/friend_list", methods=["POST"])
def friend_list():
    user_id = request.form.get("_id")
    user_info = MongoDB.Users.find_one({"_id":ObjectId(user_id)})

    RET["CODE"] = 0
    RET["MSG"] = "好友查询"
    RET["DATA"] = user_info.get("friend_list")

    return jsonify(RET)

@friends.route("/chat_list", methods=["POST"])
def chat_list():
    chat_info = request.form.to_dict()
    chat_id = ObjectId(chat_info.get("chat_id"))
    # 查询聊天窗口
    chat_window = MongoDB.Chats.find_one({"_id":chat_id})
    # 获取聊天记录
    chat_window_list = chat_window.get("chat_list")[-5:]
    # 返回聊天记录 条目[-5:]
    RET["CODE"] = 0
    RET["MSG"] = "好友查询"
    RET["DATA"] = chat_window_list

    return jsonify(RET)


@friends.route("/recv_msg", methods=["POST"])
def recv_msg():
    chat_info = request.form.to_dict()
    sender = chat_info.get("from_user")
    receiver = chat_info.get("to_user")

    count = get_msg_one(sender,receiver)

    user_list = [sender,receiver]

    chat_window =  MongoDB.Chats.find_one({"user_list":{"$all":user_list}})

    # 收最后一条数据
    ch = chat_window.get("chat_list")[-count:] # type:list
    ch.reverse()

    # 当收取消息时 - 不知道是谁发的
    # xxtx2 = "以下是来自xxx的消息"
    remark = "小伙伴"
    toy = MongoDB.Toys.find_one({"_id":ObjectId(receiver)})
    for friend in toy.get("friend_list"):
        if friend.get("friend_id") == sender:
            remark = friend.get("friend_remark")
    xxtx = text2audio(f"以下是来自{remark}的{count}条消息")

    xxtx_dict = {
        "from_user": sender,
        "to_user": receiver,
        "chat": xxtx,
        "createTime": time.time()
    }

    ch.append(xxtx_dict)


    return jsonify(ch)
