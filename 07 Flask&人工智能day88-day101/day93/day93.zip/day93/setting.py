# -*- coding: utf-8 -*-
# __author__ = "maple"


from pymongo import MongoClient

MC = MongoClient("127.0.0.1",27017)
MongoDB = MC["S21DAY93"]