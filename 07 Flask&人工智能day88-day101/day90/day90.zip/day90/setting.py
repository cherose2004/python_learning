# -*- coding: utf-8 -*-
# __author__ = "maple"


class DebugConfig(object):
    SESSION_TYPE = "redis"
    写出花 = 123
