# import os
#
# res = os.system("ipconfig")
# print(res)



