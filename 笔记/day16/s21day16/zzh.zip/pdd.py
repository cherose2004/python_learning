#!/usr/bin/env python
# -*- coding:utf-8 -*-
def f1():
    print('pdd')